<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login Page</title>
  <style>
    @font-face {
      font-family: 'GFFLatin';
      src: url('assets/GFF-Latin-Medium.ttf') format('truetype');
      font-weight: normal;
      font-style: normal;
    }

    :root {
      --cut-x-inner: 4px;
      --cut-y-inner: calc(var(--cut-x-inner) * 0.9);
      --cut-x-middle: 4px;
      --cut-y-middle: calc(var(--cut-x-middle) * 0.9);
      --cut-x-outer: 5px;
      --cut-y-outer: calc(var(--cut-x-outer) * 0.9);

      --outline-color: #D9D8D6;
      --login-bg: #191215;
      --signup-bg: #D9D8D6;
      --login-text: #D9D8D6;
      --signup-text: #191215;
      --rounded-login: 4px;
    }

    body {
      margin: 0;
      height: 100vh;
      background: url('assets/background.png') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'GFFLatin', sans-serif;
    }

    .card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      width: 340px;
      box-sizing: border-box;
      color: white;
    }

    .card h2 {
      margin-top: 0;
      margin-bottom: 16px;
      font-size: 24px;
      text-align: center;
    }

    .card label {
      display: block;
      margin-bottom: 4px;
      font-size: 14px;
    }

    .card input[type="text"],
    .card input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 16px;
      border-radius: 8px;
      border: none;
      background: rgba(255, 255, 255, 0.1);
      color: white;
      font-family: 'GFFLatin', sans-serif;
    }

    .card input::placeholder {
      color: rgba(255, 255, 255, 0.5);
    }

    .remember-me {
      display: flex;
      align-items: center;
      margin-bottom: 16px;
    }

    .remember-me input {
      margin-right: 8px;
    }

    .super-wrapper {
      width: 100%;
      height: 50px;
      background-color: var(--outline-color);
      clip-path: polygon(
        var(--cut-x-outer) 0%,
        100% 0%,
        100% calc(100% - var(--cut-y-outer)),
        calc(100% - var(--cut-x-outer)) 100%,
        0% 100%,
        0% var(--cut-y-outer)
      );
      display: flex;
      padding: 0.5px;
      box-sizing: border-box;
      margin-top: 8px;
    }

    .outline-wrapper {
      width: 100%;
      height: 100%;
      background-color: var(--outline-color);
      clip-path: polygon(
        var(--cut-x-middle) 0%,
        100% 0%,
        100% calc(100% - var(--cut-y-middle)),
        calc(100% - var(--cut-x-middle)) 100%,
        0% 100%,
        0% var(--cut-y-middle)
      );
      display: flex;
      padding: 1.5px;
      box-sizing: border-box;
    }

    .button-inner {
      width: 100%;
      height: 100%;
      display: flex;
      clip-path: polygon(
        var(--cut-x-inner) 0%,
        100% 0%,
        100% calc(100% - var(--cut-y-inner)),
        calc(100% - var(--cut-x-inner)) 100%,
        0% 100%,
        0% var(--cut-y-inner)
      );
      overflow: hidden;
      box-sizing: border-box;
    }

    .button-inner button {
      flex: 1;
      font-size: 16px;
      font-weight: bold;
      border: none;
      height: 100%;
      cursor: pointer;
      box-sizing: border-box;
      font-family: 'GFFLatin', sans-serif;
    }

    .btn-login {
      background-color: var(--login-bg);
      color: var(--login-text);
      border-top-right-radius: var(--rounded-login);
      border-bottom-right-radius: var(--rounded-login);
    }

    .btn-signup {
      background-color: var(--signup-bg);
      color: var(--signup-text);
      border-radius: 0;
    }

    .button-inner button:focus {
      outline: none;
    }
  </style>
</head>
<body>

  <div class="card">
    <h2>Login</h2>
    <form method="POST" action="process.php">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required placeholder="Enter your username">

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required placeholder="Enter your password">

      <div class="remember-me">
        <input type="checkbox" id="remember">
        <label for="remember">Remember Me</label>
      </div>

      <div class="super-wrapper">
        <div class="outline-wrapper">
          <div class="button-inner">
            <button class="btn-login" name="action" value="login">Login</button>
            <button class="btn-signup" name="action" value="signup" type="submit">Sign Up</button>
          </div>
        </div>
      </div>
    </form>
  </div>

</body>
</html>
