<?php
$csvFile = 'data/database.csv';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $action = $_POST['action'];

    if ($action === 'signup') {
        // Simpan ke database.csv
        if (!is_dir('data')) {
            mkdir('data', 0777, true); // buat folder jika belum ada
        }
        $file = fopen($csvFile, 'a');
        fputcsv($file, [$username, $password]);
        fclose($file);
        echo "<script>alert('Akun berhasil dibuat!'); window.location='index.php';</script>";
    }

    if ($action === 'login') {
        // Cek database.csv
        if (!file_exists($csvFile)) {
            echo "<script>alert('Belum ada akun terdaftar!'); window.location='index.php';</script>";
            exit;
        }

        $found = false;
        if (($handle = fopen($csvFile, 'r')) !== false) {
            while (($data = fgetcsv($handle)) !== false) {
                if ($data[0] === $username && $data[1] === $password) {
                    $found = true;
                    break;
                }
            }
            fclose($handle);
        }

        if ($found) {
            header("Location: dashboard.html");
            exit;
        } else {
            echo "<script>alert('Username atau Password salah!'); window.location='index.php';</script>";
        }
    }
}
?>
